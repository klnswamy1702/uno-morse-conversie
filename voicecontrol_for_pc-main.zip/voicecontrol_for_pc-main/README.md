# Voice Control for a PC

This project is about designing a voice
control which helps us do the tasks on a PC which is better than many voice
assistants. It can do many tasks which an OS can do and some
tasks which the existing voice assistants cannot do like we can even
use it to fill a form by our voice. We can communicate with this
assistant to search on google or YouTube or anything. We can
use it to create, open folders and files, run files, delete folders
and file, shutdown. Many things are possible.

# For Execution 
Run sdf.py in your IDLE.

