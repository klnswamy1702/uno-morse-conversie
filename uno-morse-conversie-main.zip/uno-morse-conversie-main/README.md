# Uno Morse Conversie

It is a Machine Learning project basically.
Here, we converted single button inputted Morse code into audio using Kmeans clustering.

UNO - Single button input

Morse - Morse code

Conversie - Conversion of Morse

Please look Report & PPT for clear understanding
