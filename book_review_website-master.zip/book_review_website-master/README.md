# Book Review Website - Identify expert reviews
Project is about identifying expert review in a book review
website. Book review website is a site where a user can post
his/her reviews on any book, get to know which is expert review
out of existing reviews so that he/she can get a clear idea about
the book. Django, HTML, CSS are used for front end ML for
figuring out expert answer, SQLite3 to store the data are used
in the backend.

# For Execution
Execute manage.py in the src folder using "python(or python3) manage.py runserver"
